package com.model;

import java.time.LocalDateTime;

public class Slot implements Comparable<Slot>{
	LocalDateTime startTime;
	LocalDateTime endTime;
	public Slot(){
		
	}
	public Slot(LocalDateTime startTime, LocalDateTime endTime) {
		super();
		this.startTime = startTime;
		this.endTime = endTime;
	}
	public LocalDateTime getStartTime() {
		return startTime;
	}
	public void setStartTime(LocalDateTime startTime) {
		this.startTime = startTime;
	}
	public LocalDateTime getEndTime() {
		return endTime;
	}
	public void setEndTime(LocalDateTime endTime) {
		this.endTime = endTime;
	}
	@Override
	public int compareTo(Slot o) {
		if(startTime.isEqual(o.startTime))
			return 0;
		else if(startTime.isBefore(o.startTime))
			return 1;
		else
			return -1;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((endTime == null) ? 0 : endTime.hashCode());
		result = prime * result + ((startTime == null) ? 0 : startTime.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Slot other = (Slot) obj;
		if (endTime == null) {
			if (other.endTime != null)
				return false;
		} else if (!endTime.isBefore(other.endTime))
			return false;
		if (startTime == null) {
			if (other.startTime != null)
				return false;
		} else if (!startTime.isAfter(other.startTime))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Slot [startTime=" + startTime + ", endTime=" + endTime + "]";
	}
}
