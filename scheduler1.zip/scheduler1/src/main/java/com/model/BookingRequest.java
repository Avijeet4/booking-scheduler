package com.model;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

public class BookingRequest {
	
	String empid;
	LocalDateTime requestTime;
	LocalDate date;
	LocalTime startTime;
	LocalTime endTime;
	
	public BookingRequest() {
		
	}

	public BookingRequest(String empid, LocalDateTime requestTime, LocalDate date, LocalTime startTime,
			LocalTime endTime) {
		super();
		this.empid = empid;
		this.requestTime = requestTime;
		this.date = date;
		this.startTime = startTime;
		this.endTime = endTime;
	}

	public String getEmpid() {
		return empid;
	}

	public void setEmpid(String empid) {
		this.empid = empid;
	}

	public LocalDateTime getRequestTime() {
		return requestTime;
	}

	public void setRequestTime(LocalDateTime requestTime) {
		this.requestTime = requestTime;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

	public LocalTime getStartTime() {
		return startTime;
	}

	public void setStartTime(LocalTime startTime) {
		this.startTime = startTime;
	}

	public LocalTime getEndTime() {
		return endTime;
	}

	public void setEndTime(LocalTime endTime) {
		this.endTime = endTime;
	}

	@Override
	public String toString() {
		return "BookingRequest [empid=" + empid + ", requestTime=" + requestTime + ", date=" + date + ", startTime="
				+ startTime + ", endTime=" + endTime + "]";
	}

	
	
	
}
