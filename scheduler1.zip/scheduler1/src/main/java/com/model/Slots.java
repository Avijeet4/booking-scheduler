package com.model;

import java.util.Set;
import java.util.TreeSet;

import com.model.Slot;

public class Slots {
	Set<Slot> slots=new TreeSet<>();
	
	public Slots(Slot slot){
		slots.add(slot);
	}

	public Set<Slot> getSlots() {
		return slots;
	}

	public void setSlots(Set<Slot> slots) {
		this.slots = slots;
	}
	public boolean availSlot(Slot reqSlot) {
		for(Slot slot:slots) {
			if((slot.getEndTime().isAfter(reqSlot.getEndTime())
					||slot.getEndTime().isEqual(reqSlot.getEndTime()))
				&&(slot.getStartTime().isBefore(reqSlot.getStartTime())
					||slot.getStartTime().isEqual(reqSlot.getStartTime()))) {
				slots.remove(slot);
				if(slot.getStartTime().isBefore(reqSlot.getStartTime())) {
					slots.add(new Slot(slot.getStartTime(),reqSlot.getStartTime()));
				}
				if(slot.getEndTime().isAfter(reqSlot.getEndTime())) {
					slots.add(new Slot(reqSlot.getEndTime(),slot.getEndTime()));
				}
				return true;
			}
				
		}
		return false;
	}

	@Override
	public String toString() {
		return "Slots [slots=" + slots + "]";
	}
}
