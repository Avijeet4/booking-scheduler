package com.scheduler;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

import com.model.BookingRequest;
import com.model.Slot;
import com.model.Slots;

public class Scheduler {
	
	private LocalTime officeStartTime;
	private LocalTime officeEndTime;
	private List<BookingRequest> bookings=new ArrayList<>();
	private DateTimeFormatter dateTimeFormat= DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
	private DateTimeFormatter dateFormat=DateTimeFormatter.ISO_DATE;//ofPattern("yyyy-MM-dd");
	private DateTimeFormatter timeFormat=DateTimeFormatter.ofPattern("HH:mm");
	private LocalDateTime slotStart= LocalDateTime.MAX;
	private LocalDateTime slotEnd=LocalDateTime.MIN;
	private Map<LocalDate,Set<String>>  bookedCal=new TreeMap<>();
    
	public LocalTime getOfficeStartTime() {
		return officeStartTime;
	}

	public void setOfficeStartTime(LocalTime officeStartTime) {
		this.officeStartTime = officeStartTime;
	}

	public LocalTime getOfficeEndTime() {
		return officeEndTime;
	}

	public void setOfficeEndTime(LocalTime officeEndTime) {
		this.officeEndTime = officeEndTime;
	}

	public List<BookingRequest> getBookings() {
		return bookings;
	}

	public void setBookings(List<BookingRequest> bookings) {
		this.bookings = bookings;
	}

	public LocalDateTime getSlotStart() {
		return slotStart;
	}

	public void setSlotStart(LocalDateTime slotStart) {
		this.slotStart = slotStart;
	}

	public LocalDateTime getSlotEnd() {
		return slotEnd;
	}

	public void setSlotEnd(LocalDateTime slotEnd) {
		this.slotEnd = slotEnd;
	}

	public static void main(String[] args) {
		Scheduler scheduler=new Scheduler();
		scheduler.readInput();
		scheduler.sortByReq();
		scheduler.bookMeetingRooms();
		scheduler.printBookingCalendar();
	}
	
	void readInput() {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		try {
	    	String s=br.readLine();
	    	String str[]=s.split(" ");
	    	officeStartTime=validateTime(str[0], DateTimeFormatter.ofPattern("HHmm"));
	    	officeEndTime=validateTime(str[1], DateTimeFormatter.ofPattern("HHmm"));
	        while((s = br.readLine()) != null){
	        	if(s.equalsIgnoreCase("exit")) {
	        		br.close();
	        		break;
	        	}
	        	str=s.split(" ");
		    	BookingRequest booking=new BookingRequest();
		    	booking.setRequestTime(validateDateTime(str[0]+" "+str[1],dateTimeFormat));
		    	booking.setEmpid(str[2]);
	        	
		    	s = br.readLine();
		    	str=s.split(" ");
		    	booking.setDate(validateDate(str[0], dateFormat));
		    	booking.setStartTime(validateTime(str[1], timeFormat));
		    	booking.setEndTime(validateTime(str[1], timeFormat).plusHours(Integer.parseInt(str[2])));
		    	boolean validBooking=!((booking.getStartTime().isBefore(officeStartTime))
		    			||(booking.getEndTime().isAfter(officeEndTime)));
		    	
		    	//Only take booking requests inside office hours
		    	if(validBooking) {
		    		bookings.add(booking);
		    		LocalDateTime bookingStartTime=LocalDateTime.parse(booking.getDate().format(dateFormat)+" 00:00:00",dateTimeFormat).plusHours(booking.getStartTime().getHour()).plusMinutes(booking.getStartTime().getMinute());
		    		LocalDateTime bookingEndTime=LocalDateTime.parse(booking.getDate().format(dateFormat)+" 00:00:00",dateTimeFormat).plusHours(booking.getEndTime().getHour()).plusMinutes(booking.getEndTime().getMinute());
		    		slotStart=slotStart.isBefore(bookingStartTime)?slotStart:bookingStartTime;
		    		slotEnd=slotEnd.isAfter(bookingEndTime)?slotEnd:bookingEndTime;
		    	}
	        }
	    }catch (IOException e) {
			e.printStackTrace();
		}catch(IndexOutOfBoundsException e) {
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	void sortByReq() {
		Collections.sort(bookings,new Comparator<BookingRequest>() {
	    	@Override
	    	public int compare(BookingRequest o1, BookingRequest o2) {
	    		return o1.getStartTime().isBefore(o2.getStartTime())?1:-1;
	    	}
	    });
	}
	
	void bookMeetingRooms() {
		Slot slot=new Slot(slotStart,slotEnd);
	    Slots slots=new Slots(slot);
	    
	    
	    for(BookingRequest req:bookings) {
	    	LocalDateTime reqStartTime=LocalDateTime.parse(req.getDate().format(dateFormat)+" 00:00:00",dateTimeFormat).plusHours(req.getStartTime().getHour()).plusMinutes(req.getStartTime().getMinute());
	    	LocalDateTime reqEndTime=LocalDateTime.parse(req.getDate().format(dateFormat)+" 00:00:00",dateTimeFormat).plusHours(req.getEndTime().getHour()).plusMinutes(req.getEndTime().getMinute());
	    	Slot reqSlot=new Slot(reqStartTime,reqEndTime);
	    	if(slots.availSlot(reqSlot)) {
	    		LocalDate key=LocalDate.parse(req.getDate().format(dateFormat),dateFormat);
	    		String val=req.getStartTime().format(timeFormat)+" "+req.getEndTime().format(timeFormat)+" "+req.getEmpid();
	    		if(bookedCal.containsKey(key)) {
	    			bookedCal.get(key).add(val);
	    		}else {
	    			Set<String> bookedReq=new TreeSet<>();
	    			bookedReq.add(val);
	    			bookedCal.put(key, bookedReq);
	    		}
	    	}
	    }
	}
	void printBookingCalendar() {
		for(Map.Entry<LocalDate, Set<String>> entry:bookedCal.entrySet()) {
	    	System.out.println(entry.getKey().format(dateFormat));
	    	for(String val:entry.getValue())
	    		System.out.println(val);
	    }
	}
	
	private LocalDateTime validateDateTime(String dt , DateTimeFormatter formatStrings) throws Exception {
		
	        try {
	            LocalDateTime dateTime = LocalDateTime.parse(dt,formatStrings);
	            return dateTime;
	        } catch (Exception e) {
	            //return false;
	        	throw new Exception();
	        }
	    
	  
	}
	
	private LocalDate validateDate(String dt , DateTimeFormatter formatStrings) throws Exception {
		
        try {
            LocalDate date = LocalDate.parse(dt,formatStrings);
            return date;
        } catch (Exception e) {
            //return false;
        	throw new Exception();
        }
    
	}
	
	private LocalTime validateTime(String dt , DateTimeFormatter formatStrings) throws Exception {
		
        try {
            LocalTime time = LocalTime.parse(dt,formatStrings);
            return time;
        } catch (Exception e) {
            //return false;
        	throw new Exception();
        }
    
	}
}
